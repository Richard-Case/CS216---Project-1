#ifndef STRINGS_H
#define STRINGS_H
#include <string>

// STANDARD ALERTS
const std::string alertError = "ERROR: ";
const std::string alertMissing = " not in database!";
const std::string alertWarning = "WARNING: ";
const std::string alertInvalidInput = "INVALID INPUT \nPlease Try Again...";

// STANDARD PROMPTS...
const std::string promptInput = "INPUT: ";
const std::string promptContinue = "Press ENTER to continue...";

// Clears the terminal.
const std::string clearTerminal = "\033[2J\033[1;1H";

#endif
