#include "imdb.h"

class Analyze
{
public:
	void Movies(const IMDB& imdb);
	void Actors(const IMDB& imdb);
};
